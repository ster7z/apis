const express = require('express');
const fs = require('fs');
const session = require('express-session');
const bodyParser = require('body-parser');
const ip = require('net');
const fetch = require('node-fetch');
const ssh2 = require('ssh2');
const path = require('path');

const app = express();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'html')));
app.use(express.json());

let users = [];
let configuration = [];

if (fs.existsSync('users.json')) {
  try {
    const sort = fs.readFileSync('users.json');
    users = JSON.parse(sort);
  } catch (error) {
    console.error('Error parsing user data:', error);
  }
}

if (fs.existsSync('config.json')) {
  try {
    const body = fs.readFileSync('config.json');
    configuration = JSON.parse(body);
  } catch (error) {
    console.error('Error parsing user data:', error);
  }
}

app.get('/admin', (req, res) => {
  const authenticated = req.session.authenticated || false;

  if (authenticated) {
    res.sendFile(path.join(__dirname, '/html/test.html'));
  } else {
    res.sendFile(path.join(__dirname, '/html/login.html'));
  }
});

app.post('/admin/login', (req, res) => {
  const { username, password } = req.body;

  const user = configuration.find((config) => {
    return config.user === username && config.pass === password;
  });

  if (user) {
    req.session.authenticated = true;
    res.redirect('/admin');
  } else {
    res.send('Invalid username or password');
  }
});

app.use((req, res, next) => {
  const authenticated = req.session.authenticated || false;

  if (req.path !== '/admin' || authenticated) {
    next();
  } else {
    res.redirect('/admin');
  }
});

app.get('/api/attack', (req, res) => {
  async function sendWebhook() {
    const payload = {
      content: null,
      embeds: [
        {
          color: null,
          fields: [
            { name: 'User', value: "```\n" + ('' + req.query.username) + "\n```" },
            { name: 'IP', value: "```\n" + ('' + req.query.host) + "\n```", inline: true },
            { name: 'PORT', value: "```\n" + ('' + req.query.port) + "\n```", inline: true },
            { name: 'Method', value: "```\n" + ('' + req.query.method) + "\n```", inline: true },
            { name: 'Time', value: "```\n" + ('' + req.query.time) + "\n```", inline: true },
            {
              name: 'Logs',
              value:
                "```json\n{\n    \"success\":\"true\",\n    \"message\": \"Attack sent successfully\",\n    \"host\": " +
                ('' + req.query.host) +
                ", \n    \"method\": " +
                ('' + req.query.method) +
                ", \n    \"port\": " +
                ('' + req.query.port) +
                ", \n    \"time\": " +
                ('' + req.query.time) +
                "\n  }\n```",
            },
          ],
        },
      ],
      attachments: [],
    };

    try {
      const result = await fetch(configuration[0].webhook, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!result.ok) {
        console.error('Failed to send webhook request:', result.status, result.statusText);
      }
    } catch (error) {
      console.error('Error sending webhook request:', error);
    }
  }

  // DDoS attack code

  data.host = '' + req.query.host;
  data.method = '' + req.query.method;
  data.port = '' + req.query.port;
  data.time = '' + req.query.time;

  res.json(data);

  sendWebhook();
});

app.get('/api/methods', (req, res) => {
  const methods = configuration[0].Methods;
  const methodNames = Object.keys(methods).join('\n');

  res.setHeader('Content-Type', 'text/plain');
  res.send(methodNames);
});

app.get('/', (req, res) => {
  const methods = configuration[0].Methods;
  const servers = configuration[0].Servers;
  const methodNames = Object.keys(methods).join('\n');

  res.setHeader('Content-Type', 'text/plain');
  res.send(methodNames);
});

app.get('/', (req, res) => {
  const methods = configuration[0].Methods;
  const servers = configuration[0].Servers;
  const methodNames = Object.keys(methods).join('\n');

  res.setHeader('Content-Type', 'text/plain');
  res.send(`\nApis nigaa jawa\n\nServers: ${servers.length}\n\nUsers: ${users.length}\n\n\nNumber of Methods: ${Object.keys(methods).length}\n\nMethods: \n${methodNames}\n`);
});

app.get('*', (req, res) => {
  res.status(503).send('Service Unavailable');
});

app.post('*', (req, res) => {
  res.status(503).send('Service Unavailable');
});

function saveUsers() {
  fs.writeFileSync('users.json', JSON.stringify(users, null, 2));
}

app.listen(80, () => {
  console.log('Authentication system running on port 80');
});